/**
 * Content Script（备用）
 * 实际扫描与截图定位逻辑已通过 chrome.scripting.executeScript 从 popup.js 直接注入，
 * 无需依赖此文件是否提前注入。保留此文件仅为防止扩展加载时报错。
 */
